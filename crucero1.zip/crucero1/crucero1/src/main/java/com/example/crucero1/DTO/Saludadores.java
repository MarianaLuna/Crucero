package com.example.crucero1.DTO;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Saludadores {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String nombre;
	private String fechaO;
	private String fechaD;
	private Integer costoT;
	
	
	
	public Integer getId() {
		return id;
	}
	public String getFechaO() {
		return fechaO;
	}
	public void setFechaO(String fechaO) {
		this.fechaO = fechaO;
	}
	public String getFechaD() {
		return fechaD;
	}
	public void setFechaD(String fechaD) {
		this.fechaD = fechaD;
	}
	public Integer getCostoT() {
		return costoT;
	}
	public void setCostoT(Integer costoT) {
		this.costoT = costoT;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
