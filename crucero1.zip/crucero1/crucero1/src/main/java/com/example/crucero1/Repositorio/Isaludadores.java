package com.example.crucero1.Repositorio;

import org.springframework.data.repository.CrudRepository;
import com.example.crucero1.DTO.Saludadores;

public interface Isaludadores extends CrudRepository<Saludadores, Integer> {

}
