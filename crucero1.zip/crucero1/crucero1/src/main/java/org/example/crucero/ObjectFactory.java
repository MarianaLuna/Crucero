//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2020.04.03 a las 11:01:42 PM CST 
//


package org.example.crucero;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.example.crucero package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.example.crucero
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link VerReservacionResponse }
     * 
     */
    public VerReservacionResponse createVerReservacionResponse() {
        return new VerReservacionResponse();
    }

    /**
     * Create an instance of {@link RutaRequest }
     * 
     */
    public RutaRequest createRutaRequest() {
        return new RutaRequest();
    }

    /**
     * Create an instance of {@link RutaResponse }
     * 
     */
    public RutaResponse createRutaResponse() {
        return new RutaResponse();
    }

    /**
     * Create an instance of {@link VerReservacionRequest }
     * 
     */
    public VerReservacionRequest createVerReservacionRequest() {
        return new VerReservacionRequest();
    }

    /**
     * Create an instance of {@link ReservacionRequest }
     * 
     */
    public ReservacionRequest createReservacionRequest() {
        return new ReservacionRequest();
    }

    /**
     * Create an instance of {@link EditarReservacionRequest }
     * 
     */
    public EditarReservacionRequest createEditarReservacionRequest() {
        return new EditarReservacionRequest();
    }

    /**
     * Create an instance of {@link EliminarReservacionResponse }
     * 
     */
    public EliminarReservacionResponse createEliminarReservacionResponse() {
        return new EliminarReservacionResponse();
    }

    /**
     * Create an instance of {@link EditarReservacionResponse }
     * 
     */
    public EditarReservacionResponse createEditarReservacionResponse() {
        return new EditarReservacionResponse();
    }

    /**
     * Create an instance of {@link EliminarReservacionRequest }
     * 
     */
    public EliminarReservacionRequest createEliminarReservacionRequest() {
        return new EliminarReservacionRequest();
    }

    /**
     * Create an instance of {@link ReservacionResponse }
     * 
     */
    public ReservacionResponse createReservacionResponse() {
        return new ReservacionResponse();
    }

}
