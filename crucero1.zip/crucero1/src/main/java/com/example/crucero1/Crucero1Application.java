package com.example.crucero1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Crucero1Application {

	public static void main(String[] args) {
		SpringApplication.run(Crucero1Application.class, args);
	}

}
